import torch
import torch.nn as nn
#########################
class EmbeddingHandler:
    def __init__(self):
        self._vocab = None

    @property
    def vocab(self):
        return self._vocab

    @vocab.setter
    def vocab(self, vocab):
        self._vocab = vocab

    def create_embedding(self):
        raise NotImplementedError

    def get_embedding_layer(self, project, layer_type, embed_size):
        if layer_type == "EmbeddingLayer":
            return EmbeddingLayer(project, embed_size)

class EmbeddingLayer(EmbeddingHandler):
    def __init__(self, project, embed_size):
        self.embed_size = embed_size
        try:
            self.embedder = torch.load(f'./EmbeddingModel/{project}-EmbeddingLayer.pt')
        except FileNotFoundError:
            self.embedder = nn.Embedding(num_embeddings=len(super().vocab), embedding_dim=embed_size)
            torch.save(self.embedder, f'./EmbeddingModel/{project}-EmbeddingLayer.pt')

    def create_embedding(self, sequences, max_length):
        embedded_sequences = None
        for seq in sequences:
            temp_embedding = []
            for i in range(max_length):
                try:
                    word = seq[i]
                    with torch.no_grad():
                        try:
                            index = torch.tensor(super().vocab.index(word))
                            temp_embedding.append(index)
                        except ValueError:
                            continue
                except IndexError:
                    continue
            if len(temp_embedding) > 3:
                with torch.no_grad():
                    temp_embedding = self.embedder(torch.tensor(temp_embedding))
                for _ in range(max_length - len(temp_embedding)):
                    temp_embedding = torch.cat((temp_embedding, torch.zeros(1, self.embed_size)), dim=0)
                if embedded_sequences is None:
                    embedded_sequences = temp_embedding.view(1, -1, self.embed_size)
                else:
                    embedded_sequences = torch.cat((embedded_sequences, temp_embedding.view(1, -1, self.embed_size)), dim=0)
        return embedded_sequences
