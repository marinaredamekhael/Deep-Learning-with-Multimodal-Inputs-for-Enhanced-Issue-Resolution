import os
import numpy as np
from collections import Counter
import time
import torch
import torch.nn as nn
import pandas as pd
import random

from TextProcessor import TextProcessor
from ModelTrainer import ModelTrainer
from PredictionEvaluator import PredictionEvaluator
from LogHandler import LogHandler

from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
import torchvision.transforms as transforms
import torchvision
from PIL import Image

Image.MAX_IMAGE_PIXELS = None

# Setting the random seed
SEED = 42
random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

# Device configuration
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'


class TextEmbedding:
    def __init__(self, project_name, vocabulary, embed_dim):
        self.vocabulary = vocabulary
        self.embed_dim = embed_dim
        self.model_path = f'./EmbeddingModel/{project_name}_embed_model.pt'
        try:
            self.embedding_layer = torch.load(self.model_path)
        except FileNotFoundError:
            self.embedding_layer = nn.Embedding(len(vocabulary), embed_dim)
            torch.save(self.embedding_layer, self.model_path)

    def generate_embeddings(self, sentences, max_length):
        embedded_sentences = None
        for sentence in sentences:
            sentence_indices = [
                torch.tensor(self.vocabulary.index(word))
                for word in sentence[:max_length]
                if word in self.vocabulary
            ]
            if not sentence_indices:
                continue

            with torch.no_grad():
                embedded_sentence = self.embedding_layer(torch.tensor(sentence_indices))
                padding = torch.zeros(max_length - len(embedded_sentence), self.embed_dim)
                embedded_sentence = torch.cat((embedded_sentence, padding), dim=0)

            if embedded_sentences is None:
                embedded_sentences = embedded_sentence.unsqueeze(0)
            else:
                embedded_sentences = torch.cat((embedded_sentences, embedded_sentence.unsqueeze(0)), dim=0)
        return embedded_sentences


class ResultEvaluator:
    def __init__(self, project, results_dir, model_id):
        self.results_dir = results_dir
        self.model_id = model_id
        self.project = project

    def calculate_metrics(self, predictions, actuals):
        log = LogHandler(f'{self.results_dir}/{self.project}/{self.model_id}.txt')
        log.write(f'Real Distribution: {dict(Counter(actuals))}\n')
        log.write(f'Predicted Distribution: {dict(Counter(predictions))}\n')

        metrics = {
            "precision": precision_score(actuals, predictions, average='weighted', zero_division=0),
            "recall": recall_score(actuals, predictions, average='weighted', zero_division=0),
            "f1": f1_score(actuals, predictions, average='weighted', zero_division=0),
            "accuracy": accuracy_score(actuals, predictions),
        }

        log.write(f'Performance Metrics:\n{metrics}\n')
        print(f'Model: {self.model_id}\nMetrics:\n{metrics}')


class App:
    def __init__(self):
        pass

    def execute(self):
        data_dir = './data/'
        project = 'vscode'

        labels = ['bug', 'feature']
        train_data, test_data = self.load_data(data_dir, project)
        vocab = sorted(list(set(word for sentence in train_data for word in sentence[0])))

        max_length = max(
            max(len(sentence[0]) for sentence in train_data),
            max(len(sentence[0]) for sentence in test_data),
        )

        embed_layer = TextEmbedding(project, vocab, 300)
        train_embeddings = embed_layer.generate_embeddings([sentence[0] for sentence in train_data], max_length)
        train_labels = torch.tensor([labels.index(sentence[1]) for sentence in train_data])

        self.train_model(train_embeddings, train_labels, project)
        self.test_model(test_data, embed_layer, labels, max_length, project)

    def load_data(self, base_dir, project):
        train_path = os.path.join(base_dir, f'{project}_train.csv')
        test_path = os.path.join(base_dir, f'{project}_test.csv')

        train_df = pd.read_csv(train_path)
        test_df = pd.read_csv(test_path)

        train_data = list(zip(train_df['title'], train_df['label']))
        test_data = list(zip(test_df['title'], test_df['label']))

        return train_data, test_data

    def train_model(self, embeddings, labels, project):
        trainer = ModelTrainer(project, './models/')
        trainer.train(embeddings, labels)

    def test_model(self, test_data, embed_layer, labels, max_length, project):
        test_embeddings = embed_layer.generate_embeddings([data[0] for data in test_data], max_length)
        actual_labels = [labels.index(data[1]) for data in test_data]

        evaluator = ResultEvaluator(project, './results/', 'test_model')
        evaluator.calculate_metrics(test_embeddings, actual_labels)


if __name__ == "__main__":
    start_time = time.time()
    app = App()
    app.execute()
    print(f"Execution Time: {time.time() - start_time:.2f} seconds")
