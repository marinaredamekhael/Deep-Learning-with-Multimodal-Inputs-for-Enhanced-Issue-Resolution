import os
import numpy as np
from collections import Counter
import time
import torch
import torch.nn as nn
import pandas as pd
import random

from TextPreprocessor import TextPreprocessor
from Trainer import Trainer
from Classifier import Classifier
from Logger import Logger

from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score

# Set random seed for reproducibility
SEED = 42
random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'


class EmbeddingModel:
    def __init__(self, project_name, vocabulary, embedding_dim):
        self.vocabulary = vocabulary
        self.embedding_dim = embedding_dim
        model_path = f'./EmbeddingModel/{project_name}_EmbeddingLayer.pt'

        try:
            self.model = torch.load(model_path)
        except FileNotFoundError:
            self.model = nn.Embedding(len(vocabulary), embedding_dim)
            torch.save(self.model, model_path)

    def generate_embeddings(self, sentences, max_length):
        embedded_sentences = []
        for sentence in sentences:
            indices = [
                self.vocabulary.index(word) if word in self.vocabulary else 0
                for word in sentence[:max_length]
            ]
            if len(indices) < max_length:
                indices += [0] * (max_length - len(indices))
            with torch.no_grad():
                embeddings = self.model(torch.tensor(indices))
            embedded_sentences.append(embeddings)
        return torch.stack(embedded_sentences) if embedded_sentences else None


class MetricsEvaluator:
    def __init__(self, project, results_dir, model_id):
        self.results_dir = results_dir
        self.model_id = model_id
        self.project = project

    def evaluate(self, predicted, actual):
        log_path = os.path.join(self.results_dir, f'{self.project}/{self.model_id}.txt')
        logger = Logger(log_path)

        logger.log(f'Actual labels: {Counter(actual)}\n')
        logger.log(f'Predicted labels: {Counter(predicted)}\n')

        metrics = {
            "precision": precision_score(actual, predicted, average='weighted', zero_division=0),
            "recall": recall_score(actual, predicted, average='weighted', zero_division=0),
            "f1_score": f1_score(actual, predicted, average='weighted', zero_division=0),
            "accuracy": accuracy_score(actual, predicted),
        }

        for key, value in metrics.items():
            logger.log(f'{key}: {value}\n')

        print(f"Metrics for model {self.model_id} on {self.project}:\n", metrics)


class ModelPipeline:
    def __init__(self, project, model_type):
        self.project = project
        self.model_type = model_type
        self.labels = ['bug', 'feature']

    def load_data(self):
        dataset_dir = f'C://Users//MyPC//Desktop//Datasets/{self.project}'
        train_data = pd.concat([
            pd.read_csv(f'{dataset_dir}/train_data/{self.project}_train_bug.csv'),
            pd.read_csv(f'{dataset_dir}/train_data/{self.project}_train_feature.csv')
        ])
        test_data = pd.concat([
            pd.read_csv(f'{dataset_dir}/test_data/{self.project}_test_bug.csv'),
            pd.read_csv(f'{dataset_dir}/test_data/{self.project}_test_feature.csv')
        ])
        return train_data, test_data

    def preprocess_data(self, data):
        preprocessor = TextPreprocessor('default')
        processed_data, labels = zip(*[preprocessor.process(item) for item in data])
        vocabulary = preprocessor.get_vocabulary()
        return processed_data, labels, vocabulary

    def prepare_embeddings(self, sentences, labels, vocabulary, max_length):
        embedder = EmbeddingModel(self.project, vocabulary, embedding_dim=300)
        embeddings = embedder.generate_embeddings(sentences, max_length)
        label_tensors = torch.tensor([self.labels.index(label) for label in labels])
        return embeddings, label_tensors

    def train_model(self, train_data, save_path, epochs, batch_size, max_length):
        trainer = Trainer(self.project, save_path, self.model_type, epochs, 300, batch_size, max_length,
                          len(self.labels))
        trainer.fit(*train_data)

    def evaluate_model(self, test_data, save_path):
        for model_file in os.listdir(save_path):
            classifier = Classifier(self.project, save_path, model_file)
            predictions = classifier.classify(test_data[0]).cpu().numpy()
            MetricsEvaluator(self.project, './results', model_file).evaluate(predictions, test_data[1])


if __name__ == '__main__':
    pipeline = ModelPipeline(project='vscode', model_type='cnn')
    train_df, test_df = pipeline.load_data()

    train_data, train_labels, vocab = pipeline.preprocess_data(train_df.values.tolist())
    test_data, test_labels, _ = pipeline.preprocess_data(test_df.values.tolist())

    max_seq_len = max(len(seq) for seq in train_data + test_data)

    train_embeddings = pipeline.prepare_embeddings(train_data, train_labels, vocab, max_seq_len)
    test_embeddings = pipeline.prepare_embeddings(test_data, test_labels, vocab, max_seq_len)

    model_dir = './models/vscode/'
    os.makedirs(model_dir, exist_ok=True)

    pipeline.train_model(train_embeddings, model_dir, epochs=10, batch_size=32, max_length=max_seq_len)
    pipeline.evaluate_model(test_embeddings, model_dir)
