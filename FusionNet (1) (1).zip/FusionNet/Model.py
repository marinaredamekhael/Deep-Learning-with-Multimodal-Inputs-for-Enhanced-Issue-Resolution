import torch
import torch.nn as nn
from Models import Models

# Wrapper for a PyTorch deep learning model with training, prediction, saving, and loading utilities.
class DeepLearningModel:
    def __init__(self, model_type=None, num_classes=None, num_cells=None, max_length=None, is_test_mode=False):
        """
        Initializes the model, loss function, and optimizer based on the provided configuration.
        """
        if not is_test_mode:
            self.network = Models.getModel(model_type, num_classes, num_cells, max_length).cuda()
            self.loss_function = nn.CrossEntropyLoss()
            self.primary_optimizer = torch.optim.Adam(self.network.parameters(), lr=1e-4)
            self.secondary_optimizer = torch.optim.Adam(self.network.parameters(), lr=2e-4)
        else:
            self.network = None

    def train(self, inputs, targets, is_last_batch, img_features=None, code_features=None):
        """
        Trains the model for a single step based on the provided inputs and features.
        """
        if img_features is not None and code_features is not None:
            predictions = self.network(x_t=inputs, x_c=code_features, x_i=img_features)
        elif img_features is not None:
            predictions = self.network(x_t=inputs, x_i=img_features)
        elif code_features is not None:
            predictions = self.network(x_t=inputs, x_c=code_features)
        else:
            predictions = self.network(inputs)

        loss = self.loss_function(predictions, targets)
        self.primary_optimizer.zero_grad()
        loss.backward(retain_graph=True)
        self.primary_optimizer.step()

        if is_last_batch:
            loss = None

    def infer(self, inputs, img_features=None, code_features=None):
        """
        Generates predictions from the model based on the given inputs and features.
        """
        if img_features is not None and code_features is not None:
            return self.network(x_t=inputs, x_c=code_features, x_i=img_features)
        elif img_features is not None:
            return self.network(x_t=inputs, x_i=img_features)
        elif code_features is not None:
            return self.network(x_t=inputs, x_c=code_features)
        return self.network(inputs)

    def save_model(self, file_path):
        """
        Saves the model to the specified file path.
        """
        torch.save(self.network.state_dict(), file_path)

    def load_model(self, file_path, model_type=None, num_classes=None, num_cells=None, max_length=None):
        """
        Loads a model from the specified file path.
        """
        self.network = Models.getModel(model_type, num_classes, num_cells, max_length).cuda()
        self.network.load_state_dict(torch.load(file_path))
