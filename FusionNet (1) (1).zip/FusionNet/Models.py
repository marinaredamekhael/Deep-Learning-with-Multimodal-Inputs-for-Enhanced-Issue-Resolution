import torch
import torch.nn as nn
import torch.nn.functional as F

# Implements a modular deep learning framework for classification of textual, code, and image inputs.
BATCH_SIZE = 256


class ModelFactory:
    """Factory to create models based on the type."""

    @staticmethod
    def create_model(model_type, num_classes, num_features, max_length):
        model_classes = {
            'cnn': CNN,
            'multimodal_TI': MultiModalTextImage,
            'multimodal_TC': MultiModalTextCode,
            'multimodal_TIC': MultiModalTextImageCode
        }
        return model_classes[model_type](max_length, num_classes, num_features)


class BaseMultiModal(nn.Module):
    """Base class for multi-modal models."""

    def __init__(self, max_length, num_classes, num_features):
        super().__init__()
        self.max_length = max_length
        self.num_classes = num_classes
        self.num_features = num_features
        self.shared_conv_layers = self._create_conv_layers()

    def _create_conv_layers(self):
        """Creates convolutional layers shared across text/code inputs."""
        filters = [2, 3, 4, 5]
        conv_layers = nn.ModuleDict()
        for f in filters:
            conv_layers[f'conv{f}'] = nn.Conv2d(1, 64, (f, self.num_features))
        return conv_layers

    def process_input(self, x):
        """Processes an input tensor through convolution and pooling."""
        pooled_outputs = []
        for f, conv_layer in self.shared_conv_layers.items():
            conv_out = conv_layer(x)
            conv_out = conv_out.squeeze(3).permute(0, 2, 1)  # Flatten the last dimension.
            pool_size = self.max_length - int(f[-1]) + 1
            pooled_out = F.max_pool1d(conv_out, pool_size).view(x.size(0), -1)
            pooled_outputs.append(pooled_out)
        return torch.cat(pooled_outputs, dim=1)


class MultiModalTextImageCode(BaseMultiModal):
    """Model combining text, code, and image data."""

    def __init__(self, max_length, num_classes, num_features):
        super().__init__(max_length, num_classes, num_features)
        self.fc_text_code = nn.Linear(64 * 4, 64 * 4)
        self.fc_output = nn.Linear(64 * 4, num_classes)

        # Image-specific layers
        self.image_conv = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=5), nn.ReLU(),
            nn.Conv2d(16, 32, kernel_size=5), nn.ReLU(),
            nn.MaxPool2d(kernel_size=5, stride=5),
            nn.Conv2d(32, 64, kernel_size=5), nn.ReLU(),
            nn.MaxPool2d(kernel_size=5, stride=5)
        )
        self.image_fc = nn.Linear(64 * 9 * 9, 256)

    def forward(self, text_input, code_input, image_input):
        text_features = self.process_input(text_input)
        code_features = self.process_input(code_input)
        combined_features = F.relu(self.fc_text_code(text_features * code_features))

        if image_input is not None:
            image_features = self.image_conv(image_input).view(image_input.size(0), -1)
            image_features = self.image_fc(image_features)
            combined_features *= image_features

        logits = self.fc_output(combined_features)
        return F.log_softmax(logits, dim=1)


class MultiModalTextCode(BaseMultiModal):
    """Model combining text and code data."""

    def __init__(self, max_length, num_classes, num_features):
        super().__init__(max_length, num_classes, num_features)
        self.fc_output = nn.Linear(64 * 4, num_classes)

    def forward(self, text_input, code_input):
        text_features = self.process_input(text_input)
        code_features = self.process_input(code_input)
        combined_features = F.relu(text_features * code_features)
        logits = self.fc_output(combined_features)
        return F.log_softmax(logits, dim=1)
