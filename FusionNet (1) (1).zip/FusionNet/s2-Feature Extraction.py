# CNN-based Feature Extraction for Text and Code
class CNNTextCodeEmbedder(nn.Module):
    def __init__(self, embed_dim=256):
        super(CNNTextCodeEmbedder, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=embed_dim, out_channels=64, kernel_size=3)
        self.conv2 = nn.Conv1d(in_channels=64, out_channels=128, kernel_size=3)
        self.pool = nn.MaxPool1d(2)
        self.fc = nn.Linear(128, 256)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = self.pool(self.relu(self.conv2(x)))
        x = x.view(x.size(0), -1)  # Flatten
        x = self.fc(x)
        return x

# CNN-based Feature Extraction for Image
class CNNImageEmbedder(nn.Module):
    def __init__(self, embed_dim=512):
        super(CNNImageEmbedder, self).__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=5)
        self.conv2 = nn.Conv2d(64, 128, kernel_size=5)
        self.conv3 = nn.Conv2d(128, 256, kernel_size=5)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(256 * 3 * 3, embed_dim)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = self.pool(self.relu(self.conv2(x)))
        x = self.pool(self.relu(self.conv3(x)))
        x = x.view(x.size(0), -1)  # Flatten
        x = self.fc(x)
        return x
a