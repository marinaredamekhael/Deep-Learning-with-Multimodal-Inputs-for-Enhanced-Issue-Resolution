import torch
from Model import Model
from torch.utils.data import TensorDataset, DataLoader

###################################
class Classifier:
    def __init__(self, project, classifierPath, modelName):
        self.modelName = modelName
        self.model = Model(test=True)
        self.model.load(f'{classifierPath}/{project}/{modelName}')

        self.batchSize = 256

    def classify(self, data, data_img=None, data_code=None, tp='title'):
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        if data_img is not None and data_code is not None:
            text_dataset = TensorDataset(data)
            code_dataset = TensorDataset(data_code)
            text_loader = DataLoader(text_dataset, batch_size=self.batchSize, shuffle=False)
            code_loader = DataLoader(code_dataset, batch_size=self.batchSize, shuffle=False)
            img_loader = DataLoader(data_img, batch_size=self.batchSize, shuffle=False, num_workers=4)

            data = data.flip(dims=[1]).to(device) if self.modelName.startswith('rnn') else data.to(device)
            prediction = torch.tensor([]).to(device)

            for text_batch, code_batch, img_batch in zip(text_loader, code_loader, img_loader):
                x_text = text_batch[0].to(device)
                x_code = code_batch[0].to(device)
                x_img = img_batch[0].to(device)
                p = torch.argmax(self.model.predict(x_text, x_code=x_code, x_img=x_img), dim=1)
                prediction = torch.cat([prediction, p])

            return prediction

        elif data_img is not None:
            dataset = TensorDataset(data)
            loader = DataLoader(dataset, batch_size=self.batchSize, shuffle=False)
            img_loader = DataLoader(data_img, batch_size=self.batchSize, shuffle=False, num_workers=4)

            data = data.flip(dims=[1]).to(device) if self.modelName.startswith('rnn') else data.to(device)
            prediction = torch.tensor([]).to(device)

            for samples, img_batch in zip(loader, img_loader):
                x = samples[0].to(device)
                x_img = img_batch[0].to(device)
                p = torch.argmax(self.model.predict(x, x_img=x_img), dim=1)
                prediction = torch.cat([prediction, p])

            return prediction

        elif data_code is not None:
            text_dataset = TensorDataset(data)
            code_dataset = TensorDataset(data_code)
            text_loader = DataLoader(text_dataset, batch_size=self.batchSize, shuffle=False)
            code_loader = DataLoader(code_dataset, batch_size=self.batchSize, shuffle=False)

            data = data.flip(dims=[1]).to(device) if self.modelName.startswith('rnn') else data.to(device)
            prediction = torch.tensor([]).to(device)

            for text_batch, code_batch in zip(text_loader, code_loader):
                x_text = text_batch[0].to(device)
                x_code = code_batch[0].to(device)
                p = torch.argmax(self.model.predict(x_text, x_code=x_code), dim=1)
                prediction = torch.cat([prediction, p])

            return prediction

        else:
            data = data.flip(dims=[1]).to(device) if self.modelName.startswith('rnn') else data.to(device)
            prediction = torch.argmax(self.model.predict(data), dim=1)
            return prediction

    def classify_resultExtract(self, data, data_img=None, data_code=None, tp='title'):
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        if data_img is not None and data_code is not None:
            text_dataset = TensorDataset(data)
            code_dataset = TensorDataset(data_code)
            text_loader = DataLoader(text_dataset, batch_size=self.batchSize, shuffle=False)
            code_loader = DataLoader(code_dataset, batch_size=self.batchSize, shuffle=False)
            img_loader = DataLoader(data_img, batch_size=self.batchSize, shuffle=False, num_workers=4)

            data = data.flip(dims=[1]).to(device) if self.modelName.startswith('rnn') else data.to(device)
            prediction = torch.tensor([]).to(device)
            predict_val = torch.tensor([]).to(device)

            for text_batch, code_batch, img_batch in zip(text_loader, code_loader, img_loader):
                x_text = text_batch[0].to(device)
                x_code = code_batch[0].to(device)
                x_img = img_batch[0].to(device)
                p1 = self.model.predict(x_text, x_code=x_code, x_img=x_img)
                predict_val = torch.cat([predict_val, p1])
                p = torch.argmax(p1, dim=1)
                prediction = torch.cat([prediction, p])

            return prediction, predict_val

        else:
            data = data.flip(dims=[1]).to(device) if self.modelName.startswith('rnn') else data.to(device)
            p1 = self.model.predict(data)
            prediction = torch.argmax(p1, dim=1) if tp == 'title' else p1
            return prediction, p1
