# Fusion Network
class MultimodalFusionNet(nn.Module):
    def __init__(self, text_embed_dim=256, code_embed_dim=256, image_embed_dim=512, num_classes=2):
        super(MultimodalFusionNet, self).__init__()
        self.text_embedder = CNNTextCodeEmbedder(embed_dim=text_embed_dim)
        self.code_embedder = CNNTextCodeEmbedder(embed_dim=code_embed_dim)
        self.image_embedder = CNNImageEmbedder(embed_dim=image_embed_dim)

        self.fusion_fc = nn.Linear(text_embed_dim + code_embed_dim + image_embed_dim, 1024)
        self.dropout = nn.Dropout(0.5)
        self.classifier = nn.Linear(1024, num_classes)

    def forward(self, text_input, code_input, image_input):
        # Feature extraction
        text_features = self.text_embedder(text_input)
        code_features = self.code_embedder(code_input)
        image_features = self.image_embedder(image_input)

        # Fusion via element-wise multiplication
        fused_features = text_features * code_features * image_features
        fused_features = self.dropout(fused_features)

        # Classification
        output = self.classifier(fused_features)
        return output
