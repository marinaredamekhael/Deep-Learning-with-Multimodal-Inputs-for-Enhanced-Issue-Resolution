import os
import torch
import numpy as np
import pandas as pd
from PIL import Image
from collections import defaultdict
from torch import nn
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
import torchvision.transforms as T
import torchvision.datasets as D

Image.MAX_IMAGE_PIXELS = None

# Set random seed
SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class TextEmbedder:
    def __init__(self, project_name, vocab, embed_size, mode):
        self.vocab = vocab
        self.embed_size = embed_size
        self.model_path = f"./models/{project_name}_embed_{mode}.pt"
        self.embedding_layer = self._initialize_embedding()

    def _initialize_embedding(self):
        if os.path.exists(self.model_path):
            return torch.load(self.model_path)
        embedding = nn.Embedding(len(self.vocab), self.embed_size)
        torch.save(embedding, self.model_path)
        return embedding

    def generate_embeddings(self, sentences, max_length):
        embeddings = []
        for sentence in sentences:
            indices = [self.vocab.index(word) for word in sentence if word in self.vocab]
            indices = indices[:max_length]
            padding = [0] * (max_length - len(indices))
            indices += padding
            with torch.no_grad():
                embedded = self.embedding_layer(torch.tensor(indices))
                embeddings.append(embedded)
        return torch.stack(embeddings, dim=0)

class MetricsLogger:
    def __init__(self, output_path):
        self.output_path = output_path

    def log_metrics(self, y_true, y_pred):
        precision = precision_score(y_true, y_pred, average="weighted", zero_division=0)
        recall = recall_score(y_true, y_pred, average="weighted", zero_division=0)
        f1 = f1_score(y_true, y_pred, average="weighted", zero_division=0)
        accuracy = accuracy_score(y_true, y_pred)

        with open(self.output_path, "w") as file:
            file.write(f"Precision: {precision}\nRecall: {recall}\nF1 Score: {f1}\nAccuracy: {accuracy}\n")
        print(f"Metrics logged at {self.output_path}")

class DataHandler:
    def __init__(self, base_path):
        self.base_path = base_path

    def load_data(self, project_name):
        def read_csv(filename):
            return pd.read_csv(os.path.join(self.base_path, project_name, filename))

        train_data = read_csv("train.csv")
        test_data = read_csv("test.csv")

        return {
            "train": (train_data["text"].tolist(), train_data["label"].tolist()),
            "test": (test_data["text"].tolist(), test_data["label"].tolist())
        }

    def load_images(self, project_name, mode):
        transform = T.Compose([
            T.Resize((256, 256)),
            T.ToTensor(),
            T.Normalize(mean=[0.5] * 3, std=[0.5] * 3)
        ])
        path = os.path.join(self.base_path, project_name, mode)
        dataset = D.ImageFolder(root=path, transform=transform)
        return dataset

class ProjectRunner:
    def __init__(self, project, embedding_size, max_length):
        self.project = project
        self.embedding_size = embedding_size
        self.max_length = max_length

    def preprocess_and_train(self):
        data_handler = DataHandler("./data")
        datasets = data_handler.load_data(self.project)
        train_text, train_labels = datasets["train"]
        test_text, test_labels = datasets["test"]

        vocab = sorted(set(word for sentence in train_text + test_text for word in sentence.split()))
        text_embedder = TextEmbedder(self.project, vocab, self.embedding_size, "text")

        train_embeddings = text_embedder.generate_embeddings(train_text, self.max_length)
        test_embeddings = text_embedder.generate_embeddings(test_text, self.max_length)

        print(f"Training data embeddings shape: {train_embeddings.shape}")
        print(f"Testing data embeddings shape: {test_embeddings.shape}")

    def evaluate_model(self, y_true, y_pred):
        logger = MetricsLogger(f"./results/{self.project}_metrics.txt")
        logger.log_metrics(y_true, y_pred)

if __name__ == "__main__":
    runner = ProjectRunner(project="vscode", embedding_size=128, max_length=50)
    runner.preprocess_and_train()
    # Simulate evaluation
    runner.evaluate_model([1, 0, 1], [1, 1, 1])
