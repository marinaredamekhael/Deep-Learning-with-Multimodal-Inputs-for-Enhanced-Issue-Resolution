from Embedders import Embedders


class WordEmbedder:
    embedder = None

    def __init__(self, project, embeddingType, embeddingSize, wordSet, maxLen):
        self.project = project
        self.embeddingType = embeddingType
        self.embeddingSize = embeddingSize
        self.wordSet = wordSet
        self.maxLen = maxLen

    def embedding(self, data):
        import time
        if WordEmbedder.embedder is None:
            print('Initializing embedding model...')
            start_time = time.time()
            WordEmbedder.embedder = Embedders().getEmbedder(self.project, self.embeddingType, self.embeddingSize)
            end_time = time.time()
            print(f'Embedding model loaded in {end_time - start_time:.2f} seconds.')

        embedded = WordEmbedder.embedder.embedding(data, self.maxLen)
        return embedded
