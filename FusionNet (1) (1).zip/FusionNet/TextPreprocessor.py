import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import re

# nltk.download()

class TextProcessor:
    def __init__(self, content_type):
        self.word_bank = set()
        self.longest_length = 0
        self.content_type = content_type

        # Ensure stopwords are available
        try:
            self.stopwords = stopwords.words('english')
        except LookupError:
            nltk.download('stopwords')
            self.stopwords = stopwords.words('english')

        self.lemmatizer = WordNetLemmatizer()

    def preprocess(self, content):
        if self.content_type == 'UserManual':
            return self._process_manual(content)
        elif self.content_type == 'code':
            return self._process_code(content)
        else:
            return self._process_other(content)

    def _process_manual(self, text):
        processed_lines = []
        text = text.lower()
        for line in text.splitlines():
            tokens = self._process_line(line)
            if tokens and len(tokens) >= 3:
                self.longest_length = max(self.longest_length, len(tokens))
                processed_lines.append(tokens)
        return processed_lines

    def _process_code(self, data):
        code, meta = data
        processed_code = [self._clean_and_tokenize(code.lower())]
        if not processed_code[0]:
            processed_code[0].append('code')
        return processed_code, meta

    def _process_other(self, data):
        title, meta = data
        processed_title = [self._clean_and_tokenize(title.lower())]
        if not processed_title[0]:
            processed_title[0].append('title')
        return processed_title, meta

    def _process_line(self, line):
        tokens = self._tokenize_text(line)
        tokens = self._remove_stopwords(tokens)
        tokens = self._apply_pos_filter(tokens)
        tokens = self._apply_lemmatization(tokens)
        return tokens

    def _clean_and_tokenize(self, text):
        text = self._clean_text(text)
        return self._apply_lemmatization(self._tokenize_text(text))

    def _clean_text(self, text):
        text = re.sub(r'[^\w\s]', ' ', text).strip()
        text = re.sub(r'\s+', ' ', text)
        return text

    def _tokenize_text(self, text):
        return word_tokenize(text)

    def _remove_stopwords(self, tokens):
        return [token for token in tokens if token not in self.stopwords]

    def _apply_pos_filter(self, tokens):
        pos_tags = nltk.pos_tag(tokens, tagset='universal')
        return [word for word, pos in pos_tags if pos not in {'.', 'NUM'} and word.isalpha()]

    def _apply_lemmatization(self, tokens):
        return [self.lemmatizer.lemmatize(token) for token in tokens if self.word_bank.add(token) is None]
