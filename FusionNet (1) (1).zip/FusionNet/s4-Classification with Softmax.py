# Define softmax-based classifier
class BugFeatureClassifier(nn.Module):
    def __init__(self):
        super(BugFeatureClassifier, self).__init__()

    def forward(self, x):
        return F.softmax(x, dim=-1)
