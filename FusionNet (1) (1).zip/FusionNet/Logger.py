class Logger:
    def __init__(self, filepath):
        """
        Initializes the Logger to manage file logging operations.
        Opens the specified file in append mode.
        """
        self.file = open(filepath, mode='a', encoding='utf-8')  # Opening the file in append mode.

    def write_log(self, message):
        """
        Writes a log entry to the file and ensures it's saved immediately.
        """
        self.file.write(message + '\n')  # Adding a newline for clarity.
        self.file.flush()  # Ensures data is saved to the file.

    def reset_position(self, position):
        """
        Resets the file pointer to the specified position.
        Note: Seeking may not behave as expected in append mode.
        """
        self.file.seek(position)
