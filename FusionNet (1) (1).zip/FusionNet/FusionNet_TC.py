import os
import numpy as np
import pandas as pd
import random
import torch
from collections import Counter
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
from TextPreprocessor import TextPreprocessor
from Trainer import Trainer
from Classifier import Classifier
from Logger import Logger

# Set a consistent seed for reproducibility
seed_value = 42
random.seed(seed_value)
torch.manual_seed(seed_value)
torch.cuda.manual_seed_all(seed_value)

# Check for GPU availability
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class EmbeddingHandler:
    def __init__(self, project_name, vocabulary, embedding_dim, data_category):
        self.vocabulary = vocabulary
        self.embedding_dim = embedding_dim
        file_name = f"./EmbeddingModel/{project_name}_Embedding_{data_category}.pt"

        if os.path.exists(file_name):
            self.embedder = torch.load(file_name)
        else:
            self.embedder = nn.Embedding(len(vocabulary), embedding_dim)
            torch.save(self.embedder, file_name)

    def generate_embeddings(self, sequences, max_length):
        embeddings = []
        for sequence in sequences:
            indexed_sequence = [self.vocabulary.index(word) for word in sequence if word in self.vocabulary]
            indexed_sequence = indexed_sequence[:max_length]  # Trim to max length

            # Pad sequence if shorter than max_length
            while len(indexed_sequence) < max_length:
                indexed_sequence.append(0)  # Assume 0 is the padding index

            indexed_tensor = torch.tensor(indexed_sequence, device=device)
            embedding_tensor = self.embedder(indexed_tensor).detach()
            embeddings.append(embedding_tensor)

        return torch.stack(embeddings)


class MetricsEvaluator:
    @staticmethod
    def evaluate(predictions, targets, log_path, model_name):
        logger = Logger(os.path.join(log_path, f"{model_name}_evaluation.log"))

        metrics = {
            'precision': precision_score(targets, predictions, average='weighted', zero_division=0),
            'recall': recall_score(targets, predictions, average='weighted', zero_division=0),
            'f1_score': f1_score(targets, predictions, average='weighted', zero_division=0),
            'accuracy': accuracy_score(targets, predictions)
        }

        logger.log(f"Metrics for {model_name}:\n" + "\n".join(f"{k}: {v}" for k, v in metrics.items()))
        for key, value in metrics.items():
            print(f"{key.capitalize()}: {value}")


class MainRunner:
    def __init__(self, project_name, model_dir, label_set, embedding_dim=300):
        self.project_name = project_name
        self.model_dir = model_dir
        self.label_set = label_set
        self.embedding_dim = embedding_dim

    def load_data(self, data_dir):
        train_files = [os.path.join(data_dir, f"{self.project_name}_train_{label}.csv") for label in self.label_set]
        test_files = [os.path.join(data_dir, f"{self.project_name}_test_{label}.csv") for label in self.label_set]

        train_data = pd.concat([pd.read_csv(file) for file in train_files], ignore_index=True)
        test_data = pd.concat([pd.read_csv(file) for file in test_files], ignore_index=True)

        return train_data, test_data

    def preprocess_data(self, data):
        preprocessor = TextPreprocessor('general')
        processed_text, labels = [], []
        for _, row in data.iterrows():
            processed_line, label = preprocessor.pp((row['title'], row['label']))
            if processed_line:
                processed_text.append(processed_line)
                labels.append(label)
        return processed_text, labels, preprocessor.wordSet

    def execute(self, data_path):
        train_data, test_data = self.load_data(data_path)

        train_text, train_labels, text_vocab = self.preprocess_data(train_data)
        test_text, test_labels, _ = self.preprocess_data(test_data)

        max_length = int(np.percentile([len(x) for x in train_text + test_text], 75))

        text_embedder = EmbeddingHandler(self.project_name, text_vocab, self.embedding_dim, 'text')
        train_embeddings = text_embedder.generate_embeddings(train_text, max_length)
        test_embeddings = text_embedder.generate_embeddings(test_text, max_length)

        # Placeholder for model training and testing
        print("Training and testing pipeline to be implemented")


if __name__ == "__main__":
    runner = MainRunner(project_name='vscode', model_dir='./models', label_set=['bug', 'feature'])
    runner.execute(data_path='C://Users//MyPC//Desktop//Datasets')
