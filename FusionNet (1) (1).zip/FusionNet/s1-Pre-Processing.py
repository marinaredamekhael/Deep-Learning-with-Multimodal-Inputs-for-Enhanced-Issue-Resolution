import nltk
import torch
import torch.nn as nn
from torchvision import transforms
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from torch.utils.data import Dataset

# Text Preprocessing
class TextPreProcessor:
    def __init__(self):
        self.stop_words = set(stopwords.words('english'))

    def process(self, text):
        # Case folding
        text = text.lower()
        # Tokenization
        tokens = word_tokenize(text)
        # Stop-word removal
        filtered_tokens = [word for word in tokens if word.isalpha() and word not in self.stop_words]
        return filtered_tokens

# Code Preprocessing
class CodePreProcessor:
    def __init__(self):
        pass

    def process(self, code):
        # Remove comments, case-folding, and tokenize
        code = code.lower()  # Case folding
        tokens = word_tokenize(code)  # Tokenization
        return tokens

# Image Preprocessing
class ImagePreProcessor:
    def __init__(self):
        self.transform = transforms.Compose([
            transforms.Resize((258, 258)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
        ])

    def process(self, image):
        return self.transform(image)
