from collections import Counter
import pandas as pd
from Logger import Logger
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score


class ModelEvaluator:
    def __init__(self, project, model, result_directory, manuals, issues, num_classes):
        self.result_directory = result_directory
        self.model = model
        self.project = project
        self.manuals = manuals
        self.issues = issues
        self.num_classes = num_classes
        self._prepare_data()

    def _prepare_data(self):
        if self.project == 'komodo':
            self.documents = [manual.url.replace(' ', '-').lower() for manual in self.manuals]
        elif self.project == 'vscode':
            self.documents = [manual.name.replace(' ', '-').lower().split('/')[-1] for manual in self.manuals]
        else:
            self.documents = [manual.name.replace(' ', '-').lower() for manual in self.manuals]

        answer_path = './AnswerSet/'
        data = pd.read_csv(answer_path + self.project + '.csv', encoding='cp949')
        data = data[['Document Files', 'Issue Number']].dropna()

        for issue in self.issues:
            idx = data[data['Issue Number'] == int(issue.number)].index
            try:
                doc = data.iloc[idx]['Document Files'].values[0].split('.')[0].strip().replace(' ', '-').lower()
                issue.real_class = self.documents.index(doc)
            except IndexError:
                self.issues.remove(issue)

    def evaluate(self, tp='title'):
        model_parts = self.model.split('-')
        component = model_parts[0]
        embedding_method = model_parts[1] if model_parts[1] != 'EmbeddingLayer' else 'E'

        if embedding_method == 'FastText':
            embedding_method = 'F'
        elif embedding_method == 'W2V':
            embedding_method = 'W'
        else:
            embedding_method = 'G'

        epoch = model_parts[-1].split('.')[0]

        result_file = f'{self.result_directory}/{self.project}/{tp}/{component}/{embedding_method}/{epoch}.txt'
        logger = Logger(result_file)
        logger.seek(0)

        real_labels = []
        predicted_labels = []

        for issue in self.issues:
            if tp == 'title' and issue.title_vectors is not None and issue.real_class is not None:
                real_labels.append(issue.real_class)
                predicted_labels.append(issue.title_predicted_class)
            elif issue.body_vectors is not None and issue.real_class is not None:
                real_labels.append(issue.real_class)
                predicted_labels.append(issue.body_predicted_class)

        adjusted_real = self._adjust_labels(real_labels)
        adjusted_predicted = self._adjust_labels(predicted_labels)

        logger.log(f'real=> {str(Counter(adjusted_real))}\n')
        logger.log(f'predicted=> {str(Counter(adjusted_predicted))}\n')

        precision = precision_score(real_labels, predicted_labels, average='weighted', zero_division=0)
        recall = recall_score(real_labels, predicted_labels, average='weighted', zero_division=0)
        f1 = f1_score(real_labels, predicted_labels, average='weighted', zero_division=0)
        accuracy = accuracy_score(real_labels, predicted_labels)

        logger.log(
            f'-------weighted-------\nprecision: {precision}\nrecall: {recall}\nf1-score: {f1}\naccuracy: {accuracy}\n')

    def _adjust_labels(self, labels):
        adjusted = dict(Counter(labels))
        for doc in self.documents:
            if doc in adjusted:
                adjusted[doc] = adjusted.pop(self.documents.index(doc))
        return adjusted
