import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from Model import Model

class Trainer:
    def __init__(self, project, classifierPath, modelType, epoch, numCell, batchSize, maxLen, numClass, embeddingType):
        self.project = project
        self.modelPath = classifierPath
        self.modelType = modelType
        self.epoch = epoch
        self.numCell = numCell
        self.batchSize = batchSize
        self.maxLen = maxLen
        self.numClass = numClass
        self.embeddingType = embeddingType
        self.model = Model(modelType, numClass, numCell, maxLen)

    def _prepare_data_loaders(self, X, Y, X_img=None, X_code=None):
        if X_img is not None and X_code is not None:
            dataset_text = TensorDataset(X, Y)
            dataset_code = TensorDataset(X_code, Y)
            loader_text = DataLoader(dataset_text, batch_size=self.batchSize, shuffle=False)
            loader_code = DataLoader(dataset_code, batch_size=self.batchSize, shuffle=False)
            img_loader = DataLoader(X_img, batch_size=self.batchSize, shuffle=False, num_workers=4)
            return loader_text, loader_code, img_loader

        elif X_img is not None:
            dataset = TensorDataset(X, Y)
            loader = DataLoader(dataset, batch_size=self.batchSize, shuffle=False)
            img_loader = DataLoader(X_img, batch_size=self.batchSize, shuffle=False, num_workers=4)
            return loader, img_loader

        elif X_code is not None:
            dataset_text = TensorDataset(X, Y)
            dataset_code = TensorDataset(X_code, Y)
            loader_text = DataLoader(dataset_text, batch_size=self.batchSize, shuffle=False)
            loader_code = DataLoader(dataset_code, batch_size=self.batchSize, shuffle=False)
            return loader_text, loader_code

        else:
            dataset = TensorDataset(X, Y)
            loader = DataLoader(dataset, batch_size=self.batchSize, shuffle=False)
            return loader,

    def fit(self, X, Y, X_img=None, X_code=None):
        loaders = self._prepare_data_loaders(X, Y, X_img, X_code)
        for e in range(1, self.epoch + 1):
            print(f'{e}/{self.epoch} ', end='\r')
            _last = False

            for idx, data in enumerate(zip(*loaders)):
                if idx + 1 == len(loaders[0]):
                    _last = True

                if len(data) == 3:  # when X_img and X_code are provided
                    samples_text, samples_code, image = data
                    x_text, y = samples_text
                    x_code, _ = samples_code
                    y = y.view(-1)
                    x_text, x_code, image, y = map(lambda x: x.cuda(), [x_text, x_code, image, y])
                elif len(data) == 2:  # when only X_img or X_code are provided
                    samples, img_data = data
                    x, y = samples
                    x_img = img_data.cuda()
                    x, y = x.cuda(), y.cuda()
                else:  # when neither X_img nor X_code are provided
                    samples, = data
                    x, y = samples
                    if self.modelType == 'rnn':
                        x = torch.flip(x, dims=[1])
                    x, y = x.cuda(), y.view(-1).cuda()

                self.model.fit(x, y, _last, x_code=x_code if 'x_code' in locals() else None, x_img=x_img if 'x_img' in locals() else None)

            if e % 50 == 0:
                self.model.save(f'{self.modelPath}{self.project}/{self.modelType}-{self.embeddingType}-{e}.pt')
        print()
